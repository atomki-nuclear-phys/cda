#ifndef __PCICC32_H__
#define __PCICC32_H__

//****************************************************************************
// Copyright (C) 2000-2004  ARW Elektronik Germany
//
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
// This product is not authorized for use as critical component in 
// life support systems without the express written approval of 
// ARW Elektronik Germany.
//  
// Please announce changes and hints to ARW Elektronik
//
// Maintainer(s): Klaus Hitschler (klaus.hitschler@gmx.de)
//
//****************************************************************************

//****************************************************************************
//
// pcicc32.h -- the common header for driver and applications for the PCICC32 
// PCI to CAMAC Interface
//
// $Log: pcicc32.h,v $
// Revision 1.7  2004/08/12 19:59:19  klaus
// conversion to kernel-version 2.6, released version 6.0
//
// Revision 1.6  2002/10/15 19:01:17  klaus
// fixed bug in IOCTL defines
//
// Revision 1.5  2002/04/17 19:41:06  klaus
// added support for autoread
//
// Revision 1.4  2002/04/14 18:25:38  klaus
// added interrupt handling, driver 4.4. ...3.5.tar.gz
//
// Revision 1.3  2002/04/10 18:40:10  klaus
// compiled and modified on RedHat 7.2
//
// Revision 1.2  2001/11/20 20:12:50  klaus
// included new header and CVS log
//
//****************************************************************************

#include <asm/ioctl.h>

#define PCICC32_MAGIC ' '

typedef struct
{
	char bConnected;	/* the interface seems to be connected */
	char bFail;		    /* a timeout failure is registered     */
	char bIrq;		    /* a LAM wants to generate a IRQ       */
	char bReserve;		/* not yet used                        */
} PCICC32_STATUS;

typedef struct
{
  char bEnable;     /* set to 0 to disable, != 0 to enable */
} PCICC32_IRQ_CONTROL;

typedef struct
{
  char bOn;
} PCICC32_AUTOREAD;

#define PCICC32_IOSTATE            _IOR(PCICC32_MAGIC, 1, PCICC32_STATUS)       /* get the status of PCICC32              */
#define PCICC32_IOCNTRL            _IO(PCICC32_MAGIC, 2)       			            /* reset a timeout failure, no parameters */
#define PCICC32_CONTROL_INTERRUPTS _IOWR(PCICC32_MAGIC, 3, PCICC32_IRQ_CONTROL) /* set, clear interrupt enable            */
#define PCICC32_IOSTATE_BLOCKING   _IOR(PCICC32_MAGIC, 4, PCICC32_STATUS)       /* calls a blocking IO until interrupt    */
#define PCICC32_AUTOREAD_SWITCH    _IOWR(PCICC32_MAGIC, 4, PCICC32_AUTOREAD)    /* switches autoread on or off            */

// the returned cause of the interrupt
#define NOT_MY_INTERRUPT   0
#define PCIADA_INTERRUPT   1
#define CC32_INTERRUPT     2

// the LAM (interrupt) masks
#define LAM_IRQ             0x00FFFFFF  // there was a LAM responible for the timeout
#define CONNECTION_TIMEOUT	0x08000000  // irq raised through a connection timout
#define LAM_BUS_OR          0x10000000  // a LAM-BUS-OR is pending
#define LAM_NOT_OR          0x20000000  // a LAM-NOT-OR is pending
#define LAM_AND_OR          0x40000000  // a LAM-AND-OR is pending
#define LAM_FF              0x80000000  // the LAM-Flip-Flop was set

#endif /* __PCICC32_H__ */
